REM   Script: Exercicio_7
REM   Exercicio_7

create view Exercicio_7 AS  
     
select first_name AS Nome, JOB_TITLE AS Cargo  
     
    from HR.EMP_DETAILS_VIEW;

